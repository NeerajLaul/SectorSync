// Scoring engine based on the Python backend logic
// Maps user choices to normalized values and calculates methodology scores

export interface FactorOptions {
  [key: string]: { [option: string]: number };
}

export interface MethodSensitivities {
  [methodology: string]: { [factor: string]: number };
}

export interface UserAnswers {
  [factor: string]: string;
}

export interface Contribution {
  factor: string;
  normValue: number;
  sensitivity: number;
  delta: number;
}

export interface MethodScore {
  method: string;
  score: number;
  contributions: Contribution[];
}

export interface ScoringResult {
  inputsNormalized: { [factor: string]: number };
  ranking: MethodScore[];
  rulesApplied: any[];
  engineVersion: string;
}

// Factor options (exact labels mapped to 0 / 0.5 / 1)
export const FACTOR_OPTIONS: FactorOptions = {
  project_size: { "Small": 0.0, "Medium": 0.5, "Large": 1.0 },
  planning: { "Iterative": 0.0, "Continuous Flow": 0.5, "Up-front": 1.0 },
  sourcing: { "Internal Sourcing": 0.0, "Mixed Internal/External": 0.5, "Heavily Outsourced": 1.0 },
  goals: { "Speed": 0.0, "Predictable": 0.5, "Innovation": 1.0 },
  customer_size: { "Small": 0.0, "Medium": 0.5, "Large": 1.0 },
  customer_communication: {
    "Continuous Feedback Loops": 0.0,
    "Milestone Reviews": 0.5,
    "Performance Metrics": 1.0
  },
  payment_method: {
    "Time & Materials": 0.0,
    "Quote": 0.0,
    "Milestone Payments": 0.5,
    "Firm Fixed Price": 1.0,
    "Upfront Purchase": 1.0
  },
  design: {
    "Emergent": 0.0,
    "Partial / Iterative Design": 0.5,
    "Upfront/Complete Design": 1.0
  },
  teams: {
    "Cross-functional": 0.0,
    "Specialist": 0.5,
    "Structured Silo Teams": 1.0
  },
  development: { "Iterative": 0.0, "Incremental": 0.5, "Linear": 1.0 },
  integration_testing: { "Continuous": 0.0, "When possible": 0.5, "End Phase": 1.0 },
  closing: { "Team Acceptance": 0.0, "Customer Acceptance": 0.5, "3rd Party Acceptance": 1.0 },
};

// Method sensitivities (−1..+1)
export const METHOD_SENSITIVITIES: MethodSensitivities = {
  "Scrum": {
    project_size: -0.3, planning: -0.5, sourcing: -0.6, goals: 0.6,
    customer_size: -0.2, customer_communication: -0.5, payment_method: -0.6,
    design: -0.6, teams: -0.3, development: 0.6, integration_testing: -0.4, closing: -0.5,
  },
  "SAFe": {
    project_size: 0.7, planning: 0.3, sourcing: 0.6, goals: 0.3,
    customer_size: 0.6, customer_communication: 0.5, payment_method: 0.4,
    design: 0.3, teams: 0.7, development: 0.6, integration_testing: 0.6, closing: 0.5,
  },
  "Hybrid": {
    project_size: 0.5, planning: 0.6, sourcing: 0.5, goals: 0.2,
    customer_size: 0.4, customer_communication: 0.6, payment_method: 0.6,
    design: 0.6, teams: 0.4, development: 0.3, integration_testing: 0.5, closing: 0.6,
  },
  "Waterfall": {
    project_size: 0.3, planning: 0.9, sourcing: 0.9, goals: -0.5,
    customer_size: 0.5, customer_communication: 0.9, payment_method: 0.9,
    design: 0.9, teams: 0.8, development: 0.8, integration_testing: 0.8, closing: 0.9,
  },
  "Lean Six Sigma": {
    project_size: 0.6, planning: 0.8, sourcing: 0.5, goals: 1.0,
    customer_size: 0.6, customer_communication: 0.9, payment_method: 0.5,
    design: 0.8, teams: 0.4, development: 0.6, integration_testing: 0.8, closing: 0.9,
  },
};

export const METHOD_BIAS: { [method: string]: number } = {
  "Scrum": 0.05,
  "SAFe": 0.03,
  "Hybrid": 0.02,
  "Waterfall": 0.00,
  "Lean Six Sigma": 0.01
};

// Gates: rules that exclude methodologies
function gateHeavyPlanClose(inputs: { [key: string]: number }): [boolean, string[], string] {
  if ((inputs.planning || 0) >= 0.75 && (inputs.closing || 0) >= 0.75) {
    return [true, ["Scrum"], "High upfront planning + formal closing conflict with lightweight Scrum."];
  }
  return [false, [], ""];
}

const GATES = [gateHeavyPlanClose];

// Nudges: rules that boost scores
function nudgeLargeStructured(inputs: { [key: string]: number }): { [method: string]: number } {
  const deltas: { [method: string]: number } = {};
  if ((inputs.project_size || 0) >= 0.75 && (inputs.teams || 0) >= 0.75) {
    deltas["SAFe"] = 0.15;
    deltas["Hybrid"] = 0.10;
  }
  return deltas;
}

const NUDGES = [nudgeLargeStructured];

// Normalize user answers to 0/0.5/1 values
function normalizeAnswers(raw: UserAnswers): { [key: string]: number } {
  const normalized: { [key: string]: number } = {};
  for (const factor in FACTOR_OPTIONS) {
    if (factor in raw && raw[factor]) {
      const options = FACTOR_OPTIONS[factor];
      const userChoice = raw[factor];
      
      // Try exact match first
      if (userChoice in options) {
        normalized[factor] = options[userChoice];
      } else {
        // Try case-insensitive match
        const lower = userChoice.trim().toLowerCase();
        for (const [key, value] of Object.entries(options)) {
          if (key.toLowerCase() === lower) {
            normalized[factor] = value;
            break;
          }
        }
      }
    }
  }
  return normalized;
}

// Apply gate rules
function applyGates(inputs: { [key: string]: number }): [string[], any[]] {
  const excluded: string[] = [];
  const trace: any[] = [];
  
  for (const gate of GATES) {
    const [hit, methods, why] = gate(inputs);
    if (hit) {
      excluded.push(...methods);
      trace.push({ type: "gate", affects: methods, why });
    }
  }
  
  return [Array.from(new Set(excluded)), trace];
}

// Apply nudge rules
function applyNudges(inputs: { [key: string]: number }): [{ [method: string]: number }, any[]] {
  const delta: { [method: string]: number } = {};
  const trace: any[] = [];
  
  for (const nudge of NUDGES) {
    const d = nudge(inputs);
    if (Object.keys(d).length > 0) {
      for (const [method, value] of Object.entries(d)) {
        delta[method] = (delta[method] || 0) + value;
      }
      trace.push({ type: "nudge", delta: d });
    }
  }
  
  return [delta, trace];
}

// Main scoring function
export function scoreMethodologies(userAnswers: UserAnswers): ScoringResult {
  const normalized = normalizeAnswers(userAnswers);
  const [excluded, gateTrace] = applyGates(normalized);
  const [nudgeDelta, nudgeTrace] = applyNudges(normalized);
  
  const allScores: MethodScore[] = [];
  
  for (const [method, sensitivities] of Object.entries(METHOD_SENSITIVITIES)) {
    if (excluded.includes(method)) {
      continue;
    }
    
    let total = METHOD_BIAS[method] || 0.0;
    total += nudgeDelta[method] || 0.0;
    
    const contributions: Contribution[] = [];
    
    for (const [factor, value] of Object.entries(normalized)) {
      if (factor in sensitivities) {
        const sensitivity = sensitivities[factor];
        const delta = sensitivity * value;
        total += delta;
        
        contributions.push({
          factor,
          normValue: value,
          sensitivity,
          delta: Math.round(delta * 10000) / 10000
        });
      }
    }
    
    allScores.push({
      method,
      score: Math.round(total * 10000) / 10000,
      contributions
    });
  }
  
  allScores.sort((a, b) => b.score - a.score);
  
  return {
    inputsNormalized: normalized,
    ranking: allScores,
    rulesApplied: [...gateTrace, ...nudgeTrace],
    engineVersion: "3.0.0"
  };
}
